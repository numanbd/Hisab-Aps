হিসাব Android App Project

কী করা হয়েছে:
- আপনার HTML হিসাব অ্যাপকে Android WebView অ্যাপ বানানো হয়েছে।
- অ্যাপের নাম: হিসাব
- সম্পূর্ণ অফলাইন চলবে।
- লোকাল স্টোরেজ চালু আছে, তাই হিসাব ফোনেই সেভ থাকবে।
- Google font লিংক সরিয়ে অফলাইন ফন্ট fallback দেওয়া হয়েছে।
- Export অপশন Android-এ Share/Save হিসেবে কাজ করার জন্য bridge যোগ করা হয়েছে।
- App icon, status bar color, portrait mode সেট করা হয়েছে।

APK বানানোর নিয়ম:
1. ZIP আনজিপ করুন।
2. Android Studio খুলুন।
3. Open Project দিয়ে Hisab_Android_App_Project ফোল্ডার খুলুন।
4. Gradle Sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5. APK পাবেন: app/build/outputs/apk/debug/app-debug.apk

নোট:
প্রথমবার Android Studio ইন্টারনেট দিয়ে Gradle/Android plugin ডাউনলোড করতে পারে।
